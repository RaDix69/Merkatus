<?php 
$servidor="localhost";
$usuario="root";
$password="";
$bd="6trim_base";
$conexion=mysqli_connect($servidor,$usuario,$password,$bd) or die(msql_error());

?>